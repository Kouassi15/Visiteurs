
<?php $__env->startSection('content'); ?>

<!-- <div class="dashboard-wrapper"> -->
            <div class="container-fluid  dashboard-content ">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Visiteurs </h2>
                            <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Visiteurs</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Editer un nouveau Visiteur</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
                <div class="col-lg-1 my-3 ">
                 <a class="btn btn-primary" href="<?php echo e(route('visiteur.index')); ?>">Listes</a>
               </div>
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- basic form -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Ajouter un visiteur</h5>
                                <div class="card-body">
                                    <form action="<?php echo e(route('visiteur.update',$visiteur->id)); ?>"  method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group">
                                            <label for="nom">Nom</label>
                                            <input id="nom" type="text" name="nom" value="<?php echo e($visiteur->nom); ?>" required="" placeholder="Entrer nom du visiteur" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="prenom">Prénom</label>
                                            <input id="prenom" type="text" name="prenom" value="<?php echo e($visiteur->prenom); ?>" required="" placeholder="Entrer le prenom" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="contact">Contact</label>
                                            <input id="contact" type="text" name="contact" value="<?php echo e($visiteur->contact); ?>" placeholder="Entrer le contact" required="" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="activite">Activite</label>
                                            <input id="activite" type="text" name="activite" value="<?php echo e($visiteur->activite); ?>" placeholder="Entrer l'activite" required="" class="form-control">
                                        </div>
                                        <div class="form-group">
                                        <label for="sexe">Sexe</label>
                                        <select class="form-control " name="sexe">
                                        <option value="" selected disabled hidden>Sélectionner...</option>
                                            <option value="femme" <?php echo e($visiteur->sexe == 'femme' ? 'selected' : ''); ?>>Femme</option>
                                            <option value="homme"<?php echo e($visiteur->sexe == 'homme' ? 'selected' : ''); ?>>Homme</option>
                                        </select>
                                        </div>
                                        <div class="form-group">
                                        <label for="type_visiteur_id">Statuts</label>
                                        <select class="form-control" name="type_visiteur_id">
                                        <option value="" selected disabled hidden>Sélectionner...</option>
                                         <?php $__currentLoopData = $typevisiteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typevisiteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($typevisiteur->id); ?>"><?php echo e($typevisiteur->libelle); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                        </div>
                                        <div class="form-group">
                                        <label for="responsable_id">Responsables</label>
                                        <select class="form-control" name="responsable_id">
                                        <option value="" selected disabled hidden>Sélectionner...</option>
                                         <?php $__currentLoopData = $responsables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responsable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($responsable->id); ?>"><?php echo e($responsable->nom); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="date">Date</label>
                                            <input id="date" type="date" name="date" value="<?php echo e($visiteur->date); ?>"  required="" placeholder="Entrer nom du visiteur" class="form-control">
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-6 pl-0">
                                                <p class="text-right">
                                                    <button type="submit" class="btn btn-space btn-primary">Enregistrer</button>
                                                    <button class="btn btn-space btn-secondary">Retour</button>
                                                </p>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end basic form -->
                        <!-- ============================================================== -->
                    </div>
            </div>
        <!-- </div> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetVisiteur\resources\views/dashboard/admin/visiteur/edit.blade.php ENDPATH**/ ?>